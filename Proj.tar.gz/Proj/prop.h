#ifndef PROP_H
    #define PROP_H
    void prop(int *x, double *w);
#endif
